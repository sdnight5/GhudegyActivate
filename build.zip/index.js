function ghudegy(){
    let style = document.createElement("style");
    let div = document.createElement("div");
    let h2 = document.createElement("h2");
    let p = document.createElement("p");
    style.innerHTML = '.__float { position: fixed; right: 64px; bottom: 64px; opacity: 0.5; user-select: none; pointer-events: none; font-family: -apple-system, BlinkMacSystemFont, "맑은 고딕", "Segoe UI", Roboto, Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol" !important; } \n .__float h2 { color: #808080; font-size: 18pt; font-weight: normal; line-height: 1; margin-bottom: 8px; font-family: inherit !important; } \n .__float p { color: #808080; font-size: 11pt; line-height: 1; margin: 0; }';
    h2.innerHTML = 'Ghudegy 정품 인증';
    p.innerHTML = "[백준]으로 이동하여 Ghudegy를 정품 인증합니다.";
    div.className = "__float";
    div.appendChild(h2);
    div.appendChild(p);
    document.body.appendChild(style);
    document.body.appendChild(div);
    console.log("구데기 정품 인증이 필요합니다!!");
}

ghudegy();